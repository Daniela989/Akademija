-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.21-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for university
CREATE DATABASE IF NOT EXISTS `university` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `university`;

-- Dumping structure for table university.costumers
CREATE TABLE IF NOT EXISTS `costumers` (
  `cst_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `phone` int(9) unsigned zerofill NOT NULL DEFAULT 000000007,
  `embg` bigint(13) unsigned zerofill NOT NULL,
  `cust_type` enum('fizicko','pravno') NOT NULL DEFAULT 'fizicko',
  PRIMARY KEY (`cst_id`),
  UNIQUE KEY `full_name` (`full_name`,`embg`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table university.costumers: ~2 rows (approximately)
/*!40000 ALTER TABLE `costumers` DISABLE KEYS */;
INSERT INTO `costumers` (`cst_id`, `full_name`, `phone`, `embg`, `cust_type`) VALUES
	(5, 'ljubisa popovski', 070344221, 2238192341231, 'pravno'),
	(7, 'Daniela', 713097896, 2801837737374, 'pravno');
/*!40000 ALTER TABLE `costumers` ENABLE KEYS */;

-- Dumping structure for table university.exam
CREATE TABLE IF NOT EXISTS `exam` (
  `exam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exam_name` varchar(50) NOT NULL,
  `exam_year` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table university.exam: ~6 rows (approximately)
/*!40000 ALTER TABLE `exam` DISABLE KEYS */;
INSERT INTO `exam` (`exam_id`, `exam_name`, `exam_year`) VALUES
	(3, 'matematika 3', 3),
	(4, 'matematika 4', 4),
	(5, 'matematika 5', 5),
	(6, 'matematika 7', 7),
	(7, 'matematika 7', 7);
/*!40000 ALTER TABLE `exam` ENABLE KEYS */;

-- Dumping structure for table university.marki
CREATE TABLE IF NOT EXISTS `marki` (
  `marki_id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `marki_name` varchar(50) NOT NULL,
  `region` varchar(10) NOT NULL,
  `eu` tinyint(1) NOT NULL,
  PRIMARY KEY (`marki_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table university.marki: ~9 rows (approximately)
/*!40000 ALTER TABLE `marki` DISABLE KEYS */;
INSERT INTO `marki` (`marki_id`, `marki_name`, `region`, `eu`) VALUES
	(1, 'audi', 'D', 1),
	(2, 'Audi', 'H', 1),
	(3, 'BMW', 'H', 1),
	(6, 'lada', 'RUS', 1),
	(7, 'TOYOTA', 'JAP', 0),
	(8, 'LADA', 'RUS', 0),
	(9, 'mitsbiushi', 'jap', 0),
	(10, 'skoda', 'ceska', 1);
/*!40000 ALTER TABLE `marki` ENABLE KEYS */;

-- Dumping structure for table university.modeli
CREATE TABLE IF NOT EXISTS `modeli` (
  `modeli_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modeli_name` varchar(50) NOT NULL,
  `color` varchar(10) NOT NULL,
  `price` int(10) NOT NULL,
  `marki_id` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`modeli_id`),
  KEY `FK_modeli_marki` (`marki_id`),
  CONSTRAINT `FK_modeli_marki` FOREIGN KEY (`marki_id`) REFERENCES `marki` (`marki_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Dumping data for table university.modeli: ~9 rows (approximately)
/*!40000 ALTER TABLE `modeli` DISABLE KEYS */;
INSERT INTO `modeli` (`modeli_id`, `modeli_name`, `color`, `price`, `marki_id`) VALUES
	(4, 'a4', 'grey', 4000, 1),
	(5, 'a6', 'blue', 3890, 2),
	(6, 'a3', 'blue', 4890, 2),
	(8, 'a3', 'blue', 4890, 3),
	(9, 'a5', 'red', 135, 1),
	(10, 'a5', 'red', 135, 1),
	(11, 'a5', 'blue', 76989, 3),
	(12, 'a5', 'blue', 76989, 3),
	(13, 'dacia', 'grey', 458009, 1);
/*!40000 ALTER TABLE `modeli` ENABLE KEYS */;

-- Dumping structure for table university.sales
CREATE TABLE IF NOT EXISTS `sales` (
  `sales_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `modeli_id` int(10) unsigned NOT NULL,
  `cst_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sales_id`),
  KEY `FK_sales_costumers` (`cst_id`),
  KEY `FK_sales_modeli` (`modeli_id`),
  CONSTRAINT `FK_sales_costumers` FOREIGN KEY (`cst_id`) REFERENCES `costumers` (`cst_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_sales_modeli` FOREIGN KEY (`modeli_id`) REFERENCES `modeli` (`modeli_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table university.sales: ~0 rows (approximately)
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;

-- Dumping structure for table university.students
CREATE TABLE IF NOT EXISTS `students` (
  `st_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL DEFAULT '0',
  `last_name` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`st_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table university.students: ~4 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`st_id`, `first_name`, `last_name`) VALUES
	(2, 'angela', 'cvarkoska'),
	(3, 'Ana', 'Cvarkoska'),
	(4, 'Marko', 'Cvarkoski');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

-- Dumping structure for procedure university._delete_marki
DELIMITER //
CREATE PROCEDURE `_delete_marki`(
	IN `marki_id_new` TINYINT (1)
)
BEGIN
DELETE FROM marki
WHERE marki.marki_id=marki_id_new;
END//
DELIMITER ;

-- Dumping structure for procedure university._insert_exam
DELIMITER //
CREATE PROCEDURE `_insert_exam`(
	IN `exam_nameParam` VARCHAR(50),
	IN `exam_yearParam` TINYINT(1)
)
BEGIN
INSERT into exam(exam_name,exam_year)
VALUES (exam_nameParam,exam_yearParam);
END//
DELIMITER ;

-- Dumping structure for procedure university._insert_marki
DELIMITER //
CREATE PROCEDURE `_insert_marki`(
	IN `marki_name_new` VARCHAR(50),
	IN `region_new` VARCHAR(10),
	IN `eu_new` TINYINT(1)
)
BEGIN
INSERT INTO marki(marki.marki_name,marki.region,marki.eu)
VALUES(marki_name_new,region_new,eu_new);
END//
DELIMITER ;

-- Dumping structure for procedure university._insert_modeli
DELIMITER //
CREATE PROCEDURE `_insert_modeli`(
	IN `modeli_name_new` VARCHAR(50),
	IN `color_new` VARCHAR(10),
	IN `price_new` INT(10),
	IN `marki_id_new` TINYINT(1)
)
BEGIN
INSERT into modeli(modeli.modeli_name,modeli.color,modeli.price,modeli.marki_id)
VALUES (modeli_name_new,color_new,price_new,marki_id_new);
END//
DELIMITER ;

-- Dumping structure for procedure university._insert_students
DELIMITER //
CREATE PROCEDURE `_insert_students`(
	IN `first_nameParam` VARCHAR(25),
	IN `last_nameParam` VARCHAR(25)
)
BEGIN
INSERT INTO students(first_name,last_name)
VALUES (first_nameParam,last_nameParam);
END//
DELIMITER ;

-- Dumping structure for procedure university._select_exam
DELIMITER //
CREATE PROCEDURE `_select_exam`()
BEGIN
SELECT * FROM exam;
END//
DELIMITER ;

-- Dumping structure for procedure university._select_marki
DELIMITER //
CREATE PROCEDURE `_select_marki`()
BEGIN
SELECT * FROM marki;
END//
DELIMITER ;

-- Dumping structure for procedure university._select_modeli
DELIMITER //
CREATE PROCEDURE `_select_modeli`()
BEGIN
SELECT * FROM modeli;
END//
DELIMITER ;

-- Dumping structure for procedure university._select_students
DELIMITER //
CREATE PROCEDURE `_select_students`()
BEGIN
SELECT * FROM students;
END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
