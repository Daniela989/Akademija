<?php
class Database
{
    private $db_server="localhost";
    private $db_username="root";
    private $db_password ="";
    private $db_name="university";
    private $conn = null;
    public function __construct(){
        try {
            $this->conn = new PDO("mysql:host=".$this->db_server.";dbname=".$this->db_name, $this->db_username, $this->db_password);
            // set the PDO error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "Connected successfully";
          } catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
          }
    }
    public function insertRow($table_name,$columns, $columns_value){
        $sql="INSERT INTO $table_name ($columns) VALUES ($columns_value)";
        $this->conn->exec($sql);
    }
      
      public function deleteRow ($table_name,$pk_name,$pk_value){

      
          //DELETE FROM MARKI       WHERE MARKI_ID = 1          
      $sql="DELETE FROM $table_name WHERE $pk_name = $pk_value ";
        $this->conn->exec($sql);

    }
    public function selectRow($table_name){
      $sql	=	"SELECT * from $table_name";
      $stmt=$this->conn->prepare($sql);
      $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function updateRow($table_name,$columns,$condition){
      $sql="UPDATE $table_name
      SET $columns
      WHERE $condition";
              $this->conn->exec($sql);


    }
}
///instance
// $DB=new Database();
//$DB->insertRow("proizvodi","ime,kategorija", "'pileski gradi','pijaloci'");
//$DB->insertRow("prodazba","cena_po_parce,vkupna_cena,proizvodi_id", "100,800,2");

?>
