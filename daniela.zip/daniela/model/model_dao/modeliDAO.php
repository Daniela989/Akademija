<?php
    //children extends parent
require_once "model_pojo/modeli.php";
class ModeliDAO extends Modeli
{
	private $database =null;
	public function __construct($DB){
		$this->database  =$DB;
	}
	public function insertModeli()
	{
		$modeli_name=parent::getModeli_name();
		$color=parent::getColor();
		$price=parent::getPrice();
        $marki_id=parent::getMarkiId();
		$columns="modeli_name,color,price,marki_id";
		$column_value="'$modeli_name','$color',$price,$marki_id";
		$this->database->insertROW("modeli",$columns,$column_value);
	}
	public function deleteModeli()
	{
        $modeli_id=parent::getModeli_Id();
        $this->database->deleteRow("modeli","modeli_id",$modeli_id);
	}
	public function selectModeli()
	{
		return $this->database->selectRow("modeli  
		                                    INNER JOIN marki
		                                   ON modeli.marki_id=marki.marki_id
		");
	}
	public function updateModeli()
	{
		$modeli_name=parent::getModeli_name();
		$color=parent::getColor();
		$price=parent::getPrice();
        $marki_id=parent::getMarkiId();

		$columns="modeli_name='$modeli_name',color='$color',price='$price',marki_id='$marki_id'";
		$modeli_id=parent::getModeli_Id();

		$condition="modeli_id=$modeli_id";
		$this->database->updateRow("modeli",$columns,$condition);
	}
	
}
?>