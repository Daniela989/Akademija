<?php
    //children extends parent
require_once "model_pojo/students.php";
class StudentsDAO extends Students
{
	private $database =null;
	public function __construct($DB){
		$this->database  =$DB;
	}
	public function insertStudents()
	{
		$first_name=parent::getFirstName();
		$last_name=parent::getLastName();
		
		$columns="first_name,last_name";
		$column_value="'$first_name','$last_name'";
		$this->database->insertROW("students",$columns,$column_value);
	}
	public function deleteStudents ()
	{ 
		$st_id=parent::getStId();
        $this->database->deleteRow("students","st_id",$st_id);
	}
	public function selectStudents()
	{
		return $this->database->selectRow("students");
	}
	public function updateStudents()
	{
		$first_name=parent::getFirstName();
		$last_name=parent::getLastName();

		$columns="first_name='$first_name',last_name='$last_name'";
		$st_id=parent::getStId();

		$condition="st_id=$st_id";
		$this->database->updateRow("students",$columns,$condition);
	}
	
}
?>