<?php
    //children extends parent
require_once "model_pojo/exam.php";
class ExamDAO extends Exam
{
	private $database =null;
	public function __construct($DB){
		$this->database  =$DB;
	}
	public function insertExam()
	{
		$exam_name=parent::getExamname();
		$exam_year=parent::getExamyear();
		
		$columns="exam_name,exam_year";
		$column_value="'$exam_name','$exam_year'";
		$this->database->insertROW("exam",$columns,$column_value);
	}
	public function deleteExam ()
	{ 
		$exam_id=parent::getExamId();
        $this->database->deleteRow("exam","exam_id",$exam_id);
	}
	public function selectExam()
	{
        return $this->database->selectRow("exam");
	}
	public function updateExam()
	{
		$exam_name=parent::getExamname();
		$exam_year=parent::getExamyear();

		$columns="exam_name='$exam_name',exam_year='$exam_year'";
		$exam_id=parent::getExamid();

		$condition="exam_id=$exam_id";
		$this->database->updateRow("Exam",$columns,$condition);
	}
	
}
?>