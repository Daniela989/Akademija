<?php
    //children extends parent
require_once "model_pojo/marki.php";
class MarkiDAO extends Marki
{
	private $database =null;
	public function __construct($DB){
		$this->database  =$DB;
	}
	public function insertMarki()
	{
		$marki_name=parent::getMarkiName();
		$region=parent::getRegion();
		$eu=parent::getEu();
		$columns="marki_name,region,eu";
		$column_value="'$marki_name','$region',$eu";
		$this->database->insertROW("marki",$columns,$column_value);
	}
	public function deleteMarki()
	{ 
		$marki_id=parent::getMarkiId();
        $this->database->deleteRow("marki","marki_id",$marki_id);
	}
	public function selectMarki()
	{
		return $this->database->selectRow("marki");
	}
	public function updateMarki()
	{
		$marki_name=parent::getMarkiName();
		$region=parent::getRegion();

		$columns="marki_name='$marki_name',region='$region'";
		$marki_id=parent::getMarkiId();

		$condition="marki_id=$marki_id";
		$this->database->updateRow("marki",$columns,$condition);
	}
	
}
?>