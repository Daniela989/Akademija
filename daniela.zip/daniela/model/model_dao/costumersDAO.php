<?php
    //children extends parent
require_once "model_pojo/costumers.php";
class CostumersDAO extends Costumers
{
	private $database =null;
	public function __construct($DB){
		$this->database  =$DB;
	}
	public function insertCostumers()
	{
		$full_name=parent::getFullname();
		$phone=parent::getPhone();
		$embg=parent::getEmbg();
        $cust_type=parent::getCusttype();
		
		$columns="full_name,phone,embg,cust_type";
		$column_value="'$full_name','$phone','$embg','$cust_type'";
		$this->database->insertROW("costumers",$columns,$column_value);
	}
	public function deleteCostumers ()
	{ 
		$cst_id=parent::getCstid();
        $this->database->deleteRow("costumers","cst_id",$cst_id);
	}
	public function selectCostumers()
	{
        return $this->database->selectRow("costumers");
	}
	public function updateCostumers()
	{
		$full_name=parent::getFullname();
		$phone=parent::getPhone();
		$embg=parent::getEmbg();
        $cust_type=parent::getCusttype();

		$columns="full_name='$full_name',phone='$phone',embg='$embg',cust_type='$cust_type'";
		$cst_id=parent::getCstid();

		$condition="cst_id=$cst_id";
		$this->database->updateRow("costumers",$columns,$condition);
	}
	
}
?>