<?php
require_once "../lib/database.php";
require_once "model_dao/markiDAO.php";
$data	=	json_decode( file_get_contents("php://input"));
//var_dump($data);
//instance
$DB = new Database();
$objMarkiDAO = new MarkiDAO($DB);

$action=$data[0]->action;
switch($action)
{
	case "insert":
		echo "Insert";
		//AUDI D 1
		$marki_name		=	$data[0]->marki_name;
		$country		=	$data[0]->country;
		$eu				=	$data[0]->eu;
		$objMarkiDAO->setMarkiName($marki_name);//model_pojo
		$objMarkiDAO->setRegion($country);//model_pojo
		$objMarkiDAO->setEu($eu);//model_pojo
		$objMarkiDAO->insertMarki();//model_dao
	break;
	case "edit":
		echo "edit";
		
		//AUDI D 1
		$marki_name		=	$data[0]->marki_name;
		$country		=	$data[0]->country;
		$objMarkiDAO->setMarkiName($marki_name);//model_pojo
		$objMarkiDAO->setRegion($country);//model_pojo
		$objMarkiDAO->setMarkiId(6);//model_pojo
		$objMarkiDAO->updateMarki();//model_dao
	break;
	case "delete":
		echo "delete";
		$pk_value=$data[0]->pk_value;
		$objMarkiDAO ->setMarkiId($pk_value);
        $objMarkiDAO ->deleteMarki();
	break;
	case "select":
		echo "select";
	break;
}
?>