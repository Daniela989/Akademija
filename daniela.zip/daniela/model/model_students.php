<?php
require_once "../lib/database.php";
require_once "model_dao/studentsDAO.php";
$data	=	json_decode( file_get_contents("php://input"));
//var_dump($data);
//instance
$DB = new Database();
$objStudentsDAO = new StudentsDAO($DB);

$action=$data[0]->action;
switch($action)
{
	case "insert":
		echo "Insert";
		//AUDI D 1
		$first_name		=	$data[0]->first_name;
		$last_name		=	$data[0]->last_name;
		$objStudentsDAO->setFirstName($first_name);//model_pojo
		$objStudentsDAO->setLastName($last_name);//model_pojo
		$objStudentsDAO->insertStudents();//model_dao
	break;
	case "edit":
		echo "edit";
		
		//AUDI D 1
		$first_name		=	$data[0]->first_name;
		$last_name		=	$data[0]->last_name;
		$objStudentsDAO->setFirstName($first_name);//model_pojo
		$objStudentsDAO->setLastName($last_name);//model_pojo
		$objStudentsDAO->setStId(6);//model_pojo
		$objStudentsDAO->updateStudents();//model_dao
	break;
	case "delete":
		echo "delete";
		$pk_value=$data[0]->pk_value;
		$objStudentsDAO ->setStId($pk_value);
        $objStudentsDAO ->deleteStudents();
	break;
	case "select":
		echo "select";
	break;
}
?>