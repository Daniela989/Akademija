<?php 
require_once "../lib/database.php";
$DB = new Database();
$data = array();
//model/select.php?table_name=exam
//url             ?variable  =value
$table_name=$_GET["table_name"];
switch($table_name)
{
  case "exam":
      require_once "model_dao/examDAO.php";
      $objExamDAO = new ExamDAO($DB);
     $results= $objExamDAO ->selectExam();
     //var_dump($results); exit();
     foreach ($results as $row)
     {
         //asocijativna niza
        $data[]=array (
                 "exam_id"=>$row["exam_id"],
                 "exam_name"=>$row["exam_name"],
                 "exam_year"=>$row["exam_year"]

        );

     }//end foreach
    break;
  case "marki":
    require_once "model_dao/markiDAO.php";
    $objMarkiDAO = new MarkiDAO($DB);
   $results= $objMarkiDAO ->selectMarki();
   //var_dump($results); exit();
   foreach ($results as $row)
   {
       //asocijativna niza
      $data[]=array (
               "marki_id"=>$row["marki_id"],
               "marki_name"=>$row["marki_name"],
               "region"=>$row["region"],
               "eu"=>$row["eu"]

      );

   }//end foreach
    break;
    case "costumers":
        require_once "model_dao/costumersDAO.php";
        $objCostumersDAO = new CostumersDAO($DB);
       $results= $objCostumersDAO ->selectCostumers();
       //var_dump($results); exit();
       foreach ($results as $row)
       {
           //asocijativna niza
          $data[]=array (
                   "cst_id"=>$row["cst_id"],
                   "full_name"=>$row["full_name"],
                   "phone"=>$row["phone"],
                   "embg"=>$row["embg"],
                   "cust_type"=>$row["cust_type"]
    
          );
    
       }//end foreach
        break;
   case "modeli":

    require_once "model_dao/modeliDAO.php";
    $objModeliDAO = new ModeliDAO($DB);
   $results= $objModeliDAO ->selectModeli();
   //var_dump($results); exit();
   foreach ($results as $row)
   {
       //asocijativna niza
      $data[]=array (
               "modeli_id"=>$row["modeli_id"],
               "modeli_name"=>$row["modeli_name"],
               "color"=>$row["color"],
               "price"=>$row["price"],
               "marki_id"=>$row["marki_id"],
               "marki_name"=>$row["marki_name"],
               "region"=>$row["region"],
               "eu"=>$row["eu"]

      );
    }//end foreach
    break;
   

 case "students":
    require_once "model_dao/studentsDAO.php";
    $objStudentsDAO = new StudentsDAO($DB);
   $results= $objStudentsDAO ->selectStudents();
   //var_dump($results); exit();
   foreach ($results as $row)
   {
       //asocijativna niza
      $data[]=array (
               "st_id"=>$row["st_id"],
               "first_name"=>$row["first_name"],
               "last_name"=>$row["last_name"]
      );
    }//end foreach
    break;    
    
}//end switch
 echo json_encode($data);


?>