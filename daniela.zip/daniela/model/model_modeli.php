<?php
require_once "../lib/database.php";
require_once "model_dao/modeliDAO.php";
$data	=	json_decode( file_get_contents("php://input"));

//instance
$DB = new Database();
$objModeliDAO = new ModeliDAO($DB);

$action=$data[0]->action;
switch($action)
{
	case "insert":
		echo "Insert";
		//AUDI D 1
		$modeli_name=$data[0]->modeli_name;
		$color=$data[0]->color;
		$price=$data[0]->price;
		$marki_id=$data[0]->marki_id;


		$objModeliDAO->setModeli_name($modeli_name);//model_pojo
		$objModeliDAO->setColor($color);//model_pojo
		$objModeliDAO->setPrice($price);//model_pojo
        $objModeliDAO->setMarkiId($marki_id);//model_pojo
		$objModeliDAO->insertModeli();//model_dao
	break;
	case "edit":
		echo "edit";
		$objModeliDAO->setModeli_name("a5");//model_pojo
		$objModeliDAO->setColor("blue");//model_pojo
		$objModeliDAO->setPrice(76989);//model_pojo
		$objModeliDAO->setMarkiId(3);//model_pojo
		$objModeliDAO->setModeli_Id(2);//model_pojo
		$objModeliDAO->updateModeli();//model_dao

	break;
	case "delete":
	
	echo "delete";
	$pk_value=$data[0]->pk_value;
    $objModeliDAO ->setModeli_Id($pk_value);
    $objModeliDAO ->deleteModeli();
    
	break;
	case "select":
		echo "select";
	break;
}
?>