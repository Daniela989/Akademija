<?php
class Marki
{
	private $marki_id;
	private $marki_name;
	private $region;
	private $eu;
	
	public function setMarkiId($marki_id){
		$this->marki_id = $marki_id;
	}
	public function setMarkiName($marki_name){
		$this->marki_name = $marki_name;
	}
	public function setRegion($region){
		$this->region = $region;
	}
	public function setEu($eu){
		$this->eu = $eu;
	}
	
	
	public function getMarkiId(){
		return $this->marki_id;
	}
	public function getMarkiName(){
		return $this->marki_name;
	}
	public function getRegion(){
		return $this->region;
	}
	public function getEu(){
		return $this->eu;
	}
}
?>