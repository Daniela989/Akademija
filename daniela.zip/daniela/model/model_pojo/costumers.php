<?php
class Costumers
{
	private $cst_id;
	private $full_name;
	private $phone;
	private $embg;
	private $cust_type;
	
	
	public function setCstid($cst_id){
		$this->cst_id = $cst_id;
	}
	public function setFullname($full_name){
		$this->full_name = $full_name;
	}
	public function setPhone($phone){
		$this->phone = $phone;
	}
	public function setEmbg($embg){
		$this->embg = $embg;
	}
	public function setCusttype($cust_type){
		$this->cust_type = $cust_type;
	}

	
	
	public function getCstid(){
		return $this->cst_id ;
	}
	public function getFullname(){
		return $this->full_name;
	}
	public function getPhone(){
		return $this->phone ;
	}
	public function getEmbg(){
		return $this->embg ;
	}
	public function getCusttype(){
		return $this->cust_type;
	}
}
?>