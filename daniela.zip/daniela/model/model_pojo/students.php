<?php
class Students
{
	private $st_id;
	private $first_name;
	private $last_name;
	
	
	public function setStId($st_id){
		$this->st_id = $st_id;
	}
	public function setFirstName($first_name){
		$this->first_name = $first_name;
	}
	public function setLastName($last_name){
		$this->last_name = $last_name;
	}

	
	
	public function getStId(){
		return $this->st_id ;
	}
	public function getFirstName(){
		return $this->first_name;
	}
	public function getLastName(){
		return $this->last_name ;
	}
}
?>