<?php
class Modeli
{
	private $modeli_id;
	private $modeli_name;
	private $color;
	private $price;
    private $marki_id;
	
	public function setModeli_Id($modeli_id){
		$this->modeli_id = $modeli_id;
	}
	public function setModeli_Name($modeli_name){
		$this->modeli_name = $modeli_name;
	}
	public function setColor($color){
        $this->color = $color;
	}
	public function setPrice($price){
		$this->price = $price;
	}
    public function setMarkiId($marki_id){
        $this->marki_id = $marki_id;
    }


	
	
	public function getModeli_Id(){
		return $this->modeli_id;
	}
	public function getModeli_Name(){
		return $this->modeli_name;
	}
	public function getColor(){
		return $this->color;
	}
	public function getPrice(){
		return $this->price;
	}
    public function getMarkiId(){
        return $this->marki_id;
    }


}
?>