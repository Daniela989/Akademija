<?php
class Exam
{
	private $exam_id;
	private $exam_name;
	private $exam_year;
	
	
	
	public function setExamid($exam_id){
		$this->exam_id = $exam_id;
	}
	public function setExamname($exam_name){
		$this->exam_name = $exam_name;
	}
	public function setExamyear($exam_year){
		$this->exam_year = $exam_year;
	}
	

	
	
	public function getExamid(){
		return $this->exam_id ;
	}
	public function getExamname(){
		return $this->exam_name;
	}
	public function getExamyear(){
		return $this->exam_year ;
	}
}
	
?>