<?php
require_once "../lib/database.php";
require_once "model_dao/examDAO.php";
$data	=	json_decode( file_get_contents("php://input"));
//var_dump($data);
//instance
$DB = new Database();
$objExamDAO = new ExamDAO($DB);

$action=$data[0]->action;
switch($action)
{
	case "insert":
		echo "Insert";
		//AUDI D 1
		$exam_name		=	$data[0]->exam_name;
		$exam_year		=	$data[0]->exam_year;
		$objExamDAO->setExamname($exam_name);//model_pojo
		$objExamDAO->setExamyear($exam_year);//model_pojo
		$objExamDAO->insertExam();//model_dao
	break;
	case "edit":
		echo "edit";
		
		//AUDI D 1
		$exam_name		=	$data[0]->exam_name;
		$exam_year		=	$data[0]->exam_year;
		$objExamDAO->setExamname($exam_name);//model_pojo
		$objExamDAO->setExamyear($exam_year);//model_pojo
		$objExamDAO->setExamId(1);//model_pojo
		$objExamDAO->updateExam();//model_dao
	break;
	case "delete":
		echo "delete";
		$pk_value=$data[0]->pk_value;
		$objExamDAO ->setExamId($pk_value);
        $objExamDAO ->deleteExam();
	break;

}
?>