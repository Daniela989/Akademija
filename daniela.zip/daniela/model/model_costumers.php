<?php
require_once "../lib/database.php";
require_once "model_dao/costumersDAO.php";
$data	=	json_decode( file_get_contents("php://input"));
//var_dump($data);
//instance
$DB = new Database();
$objCostumersDAO = new CostumersDAO($DB);

$action=$data[0]->action;
switch($action)
{
	case "insert":
		echo "Insert";
		//AUDI D 1
		$full_name		=	$data[0]->full_name;
		$phone		=	$data[0]->phone;
        $embg		=	$data[0]->embg;
		$cust_type		=	$data[0]->cust_type;
		$objCostumersDAO->setFullname($full_name);//model_pojo
		$objCostumersDAO->setPhone($phone);//model_pojo
        $objCostumersDAO->setEmbg($embg);//model_pojo
		$objCostumersDAO->setCusttype($cust_type);//model_pojo
		$objCostumersDAO->insertCostumers();//model_dao
	break;
	case "edit":
		echo "edit";
		
		//AUDI D 1
		$full_name		=	$data[0]->full_name;
		$phone		=	$data[0]->phone;
        $embg		=	$data[0]->embg;
		$cust_type		=	$data[0]->cust_type;
		$objCostumersDAO->setFullname($full_name);//model_pojo
		$objCostumersDAO->setPhone($phone);//model_pojo
        $objCostumersDAO->setEmbg($embg);//model_pojo
        $objCostumersDAO->setCusttype($cust_type);//model_pojo
        $objCostumersDAO->setCstid();//model_pojo
		$objCostumersDAO->updateCostumers();//model_dao
	break;
	case "delete":
		echo "delete";
		$pk_value=$data[0]->pk_value;
		$objCostumersDAO ->setCstid($pk_value);
        $objCostumersDAO ->deleteCostumers();
	break;
	case "select":
		echo "select";
	break;
}
?>
