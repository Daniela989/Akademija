app.config(function($routeProvider) { //
  $routeProvider//
  .when("/main", { //
    templateUrl : "view/main.html",//
	controller:'myCtrl'//
  })
  .when("/about", {
    templateUrl : "view/about.html",
	controller:'myCtrl'
  })
  .when("/contact", {
    templateUrl : "view/contact.html",
	controller:'myCtrl'
  })
  .when("/marki", {//route
    templateUrl : "view/marki.html",
	controller:'myCtrl'
  })
  .when("/details_marki", {//route
    templateUrl : "view/details_marki.html",
	controller:'myCtrl'
  })
  .when("/details_modeli", {//route
    templateUrl : "view/details_modeli.html",
	controller:'myCtrl'
  })
  .when("/modeli", {//route
    templateUrl : "view/modeli.html",
	controller:'myCtrl'
  })
  
  .when("/students", {//route
    templateUrl : "view/students.html",
	controller:'myCtrl'
  })
  .when("/details_students", {//route
    templateUrl : "view/details_students.html",
	controller:'myCtrl'
  })
  .when("/exam", {//route
    templateUrl : "view/exam.html",
	controller:'myCtrl'
  })
  .when("/details_exam", {//route
    templateUrl : "view/details_exam.html",
	controller:'myCtrl'
  })
  .when("/costumers", {//route
    templateUrl : "view/costumers.html",
	controller:'myCtrl'
  })
  .when("/details_costumers", {//route
    templateUrl : "view/details_costumers.html",
	controller:'myCtrl'
  })
  .when("/sales",{
     templateUrl : "view/sales.html",
     controller:'MyCtrl'
  })
  .when("/details_sales.html",{
    templateUrl : "view/details_sales.html",
    controller:'MyCtrl'
  })


 });