var app = angular.module('myApp', ["ngRoute"]);
app.controller('myCtrl', function($scope, $http) {
 $scope.company="Softver Developer";
 $scope.danger=false;

 $scope.marki=[];
 $http.get("model/select.php?table_name=marki").then(function(response) {
   $scope.marki = response.data;
 });

 $scope.costumers=[];
 $http.get("model/select.php?table_name=costumers").then(function(response) {
   $scope.costumers = response.data;
 });

 $scope.modeli=[];
$http.get("model/select.php?table_name=modeli").then(function(response) {
  $scope.modeli = response.data;
});

$scope.students=[];
$http.get("model/select.php?table_name=students").then(function(response) {
  $scope.students = response.data;
});

$scope.exam=[];
$http.get("model/select.php?table_name=exam").then(function(response) {
  $scope.exam = response.data;
});

$scope.sales=[];
$http.get("model/select.php?table_name=sales").then(function(response){
	$scope.sales=response.data; 
});



 /****************************************************************/
 /*				FUNCTIONS										 */
 /****************************************************************/
function postData(postUrl,postData){
	$http({
		method : "POST",
		url : postUrl,
		data: postData
	}).then(function mySuccess(response) {
			//
	});

}

$scope.addCostumers=function(full_name, phone, embg,cust_type){
	var objCostumers=[];
	objCostumers.push({"full_name":full_name,
				   "phone":phone,
				   "embg":embg,
				   "cust_type":cust_type,
				   "action":"insert"});
		   //console.log(objMarki);
   postData("model/model_costumers.php",objCostumers);
	//console.log(marki_name+" "+country+" "+eu);
}

 $scope.addMarki=function(marki_name, country, eu){
	 var objMarki=[];
	 objMarki.push({"marki_name":marki_name,
					"country":country,
					"eu":eu,
					"action":"insert"});
			//console.log(objMarki);
	postData("model/model_marki.php",objMarki);
	 //console.log(marki_name+" "+country+" "+eu);
 }

$scope.addModeli=function(modeli_name, color, price,marki_id){
    var objModeli=[];
	objModeli.push({
		"modeli_name":modeli_name,
		"color":color,
		"price":price,
		"marki_id":marki_id,
		"action":"insert"});
		console.log(objModeli);
	postData("model/model_modeli.php",objModeli);
	}


	$scope.addStudents=function(first_name,last_name){
		var objStudents=[];
		objStudents.push({
			"first_name":first_name,
			"last_name":last_name,
			"action":"insert"});
			console.log(objStudents);
		postData("model/model_students.php",objStudents);
		}
		
	$scope.addExam=function(exam_name,exam_year){
		var objExam=[];
		objExam.push({
			"exam_name":exam_name,
			"exam_year":exam_year,
			"action":"insert"});
			console.log(objExam);
		postData("model/model_exam.php",objExam);
			}
		//"deleteRow('modeli')"
		$scope.deleteRow=function(table_name,pk_value)
		{
			var ObjDelete=[];
			ObjDelete.push({
				"action":"delete",
            "pk_value": pk_value
			}) ;
			console.log(ObjDelete);
			postData("model/model_"+table_name+".php",ObjDelete);
		}





});